<?php
session_start();
if (!isset($_SESSION['level'])) $_SESSION['level']=2;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <title>HCA</title>
    <style type='text/css'>
    <!--
    @import url('./css/cheers.css');
    -->
    </style>
</head>
<body>
   <div id='branding'></div>
